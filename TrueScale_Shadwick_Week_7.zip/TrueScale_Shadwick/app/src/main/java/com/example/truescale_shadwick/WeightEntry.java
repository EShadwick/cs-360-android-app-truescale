package com.example.truescale_shadwick;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * A single weigh-in row loaded from the daily_weights table.
 *
 * The date is held in ISO form (yyyy-MM-dd) because that is what SQLite
 * sorts correctly as text. Display formatting happens in getDisplayDate()
 * so the stored value and the shown value never drift apart.
 *
 * The change value is not stored in the database. It is computed when the
 * list is loaded by comparing each entry to the one before it, so that
 * inserting or deleting a row cannot leave stale deltas behind.
 */
public class WeightEntry {

    private static final SimpleDateFormat ISO_FORMAT =
            new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private static final SimpleDateFormat DISPLAY_FORMAT =
            new SimpleDateFormat("MM/dd/yyyy", Locale.US);

    private final long id;
    private final String isoDate;
    private final double weight;
    private final double change;

    public WeightEntry(long id, String isoDate, double weight, double change) {
        this.id = id;
        this.isoDate = isoDate;
        this.weight = weight;
        this.change = change;
    }

    /** Database row id, used to target update and delete operations. */
    public long getId() {
        return id;
    }

    /** The stored date in yyyy-MM-dd form. */
    public String getIsoDate() {
        return isoDate;
    }

    /**
     * The date formatted for the user as MM/dd/yyyy. Falls back to the raw
     * stored value if it cannot be parsed, so a bad row shows something
     * rather than crashing the grid.
     */
    public String getDisplayDate() {
        try {
            Date parsed = ISO_FORMAT.parse(isoDate);
            return parsed == null ? isoDate : DISPLAY_FORMAT.format(parsed);
        } catch (ParseException e) {
            return isoDate;
        }
    }

    public double getWeight() {
        return weight;
    }

    /** Pounds gained or lost since the previous weigh-in. Zero for the oldest entry. */
    public double getChange() {
        return change;
    }
}