package com.example.truescale_shadwick;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import android.widget.Toast;

/**
 * Home screen: the weight grid for the signed in user. Entries are loaded
 * from the daily_weights table each time the screen becomes visible, so a
 * row added or changed on another screen appears without further action.
 */
public class MainActivity extends AppCompatActivity implements WeightAdapter.OnEntryActionListener {

    /** Value meaning no user was passed in, which should not happen in normal use. */
    private static final long NO_USER = -1L;

    private TrueScaleDatabaseHelper databaseHelper;

    private long userId = NO_USER;
    private double goalWeight;

    private final List<WeightEntry> entries = new ArrayList<>();
    private WeightAdapter adapter;

    private RecyclerView recyclerWeights;
    private TextView textEmptyGrid;
    private TextView textCurrentWeight;
    private TextView textGoalWeight;
    private TextView textToGo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        databaseHelper = new TrueScaleDatabaseHelper(this);

        userId = getIntent().getLongExtra(LoginActivity.EXTRA_USER_ID, NO_USER);

        if (userId == NO_USER) {
            // Without a user there is no data to show and nowhere to save to,
            // so return to the login screen rather than running in a broken state.
            startActivity(new Intent(MainActivity.this, LoginActivity.class));
            finish();
            return;
        }

        recyclerWeights = findViewById(R.id.recyclerWeights);
        textEmptyGrid = findViewById(R.id.textEmptyGrid);
        textCurrentWeight = findViewById(R.id.textCurrentWeight);
        textGoalWeight = findViewById(R.id.textGoalWeight);
        textToGo = findViewById(R.id.textToGo);

        Button buttonAddWeight = findViewById(R.id.buttonAddWeight);
        Button buttonAlerts = findViewById(R.id.buttonAlerts);

        adapter = new WeightAdapter(entries, this);
        recyclerWeights.setLayoutManager(new LinearLayoutManager(this));
        recyclerWeights.setAdapter(adapter);

        buttonAddWeight.setOnClickListener(v -> openEntryScreen(NO_USER));

        buttonAlerts.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, NotificationSettingsActivity.class);
            intent.putExtra(LoginActivity.EXTRA_USER_ID, userId);
            startActivity(intent);
        });
    }

    /**
     * Reloading here rather than in onCreate means an entry saved on the add
     * or edit screen is visible as soon as the user returns to this one.
     */
    @Override
    protected void onResume() {
        super.onResume();
        if (userId != NO_USER) {
            reloadEntries();
        }
    }

    /** Pulls the current rows and goal from the database and redraws the screen. */
    private void reloadEntries() {
        goalWeight = databaseHelper.getGoalWeight(userId);

        entries.clear();
        entries.addAll(databaseHelper.getWeightEntries(userId));
        adapter.notifyDataSetChanged();

        updateSummary();
        checkGoalReached();
        }

    /**
     * Sends the goal alert when the newest weigh-in has reached the target.
     *
     * The id of the entry that triggered the alert is stored, so returning to
     * this screen or adding another entry at or below the goal does not send
     * the same congratulation again.
     *
     * The alert is only sent by text when the user has switched alerts on,
     * given a number, and granted the SMS permission. When any of those is
     * missing the message is shown in the app instead, so the feature still
     * works for a user who declined the permission.
     */
    private void checkGoalReached() {
        if (entries.isEmpty()) {
            return;
        }

        WeightEntry newest = entries.get(0);

        // Reaching the goal means weighing the target amount or less.
        if (newest.getWeight() > goalWeight) {
            return;
        }

        // Already congratulated for this weigh-in, so there is nothing to do.
        if (databaseHelper.getLastAlertEntryId(userId) == newest.getId()) {
            return;
        }

        databaseHelper.setLastAlertEntryId(userId, newest.getId());

        String phoneNumber = databaseHelper.getPhoneNumber(userId);
        boolean canSendText = databaseHelper.areAlertsEnabled(userId)
                && !phoneNumber.isEmpty();

        if (canSendText) {
            String message = getString(R.string.sms_goal_reached, goalWeight);

            if (NotificationSettingsActivity.sendSms(this, phoneNumber, message)) {
                return;
            }
        }

        // No text was sent, so the user is told inside the app instead.
        Toast.makeText(this, R.string.alert_goal_reached_in_app, Toast.LENGTH_LONG).show();
    }

    /**
     * Opens the add and edit screen. Passing NO_USER as the entry id means a
     * new weigh-in; any other value opens that existing row for editing.
     */
    private void openEntryScreen(long entryId) {
        Intent intent = new Intent(MainActivity.this, AddWeightActivity.class);
        intent.putExtra(AddWeightActivity.EXTRA_USER_ID, userId);

        if (entryId != NO_USER) {
            intent.putExtra(AddWeightActivity.EXTRA_ENTRY_ID, entryId);
        }

        startActivity(intent);
    }

    @Override
    public void onEditClick(long entryId) {
        openEntryScreen(entryId);
    }

    /**
     * Deleting a weigh-in cannot be undone, so the user is asked to confirm
     * before the row is removed from the database.
     */
    @Override
    public void onDeleteClick(long entryId) {
        new AlertDialog.Builder(this)
                .setTitle(R.string.confirm_delete_title)
                .setMessage(R.string.confirm_delete_message)
                .setPositiveButton(R.string.action_delete, (dialog, which) -> {
                    databaseHelper.deleteWeightEntry(entryId);
                    reloadEntries();
                })
                .setNegativeButton(R.string.action_cancel, null)
                .show();
    }

    /** Updates the current, goal, and remaining figures above the grid. */
    private void updateSummary() {
        boolean hasEntries = !entries.isEmpty();
        recyclerWeights.setVisibility(hasEntries ? View.VISIBLE : View.GONE);
        textEmptyGrid.setVisibility(hasEntries ? View.GONE : View.VISIBLE);

        textGoalWeight.setText(String.format(Locale.US, "%.1f", goalWeight));

        if (hasEntries) {
            // The list is newest first, so the most recent weigh-in is at the top.
            double current = entries.get(0).getWeight();
            textCurrentWeight.setText(String.format(Locale.US, "%.1f", current));
            textToGo.setText(String.format(Locale.US, "%.1f", current - goalWeight));
        } else {
            textCurrentWeight.setText(R.string.hint_weight);
            textToGo.setText(R.string.hint_weight);
        }
    }
}