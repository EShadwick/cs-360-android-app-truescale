package com.example.truescale_shadwick;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Adds a new weigh-in or edits an existing one, depending on whether an
 * entry id is passed in. The date is chosen through a calendar dialog rather
 * than typed, so an unparseable date cannot reach the database.
 *
 * Dates are shown to the user as MM/dd/yyyy and stored as yyyy-MM-dd, which
 * is the form SQLite sorts correctly when comparing text.
 */
public class AddWeightActivity extends AppCompatActivity {

    /** Row id of the user these entries belong to. */
    public static final String EXTRA_USER_ID = "com.example.truescale_shadwick.USER_ID";

    /** Row id of an entry being edited. Absent when adding a new entry. */
    public static final String EXTRA_ENTRY_ID = "com.example.truescale_shadwick.ENTRY_ID";

    /** Value meaning no entry was passed, so this is a new weigh-in. */
    private static final long NO_ENTRY = -1L;

    private static final double MIN_WEIGHT = 50.0;
    private static final double MAX_WEIGHT = 1000.0;

    private final SimpleDateFormat isoFormat =
            new SimpleDateFormat("yyyy-MM-dd", Locale.US);
    private final SimpleDateFormat displayFormat =
            new SimpleDateFormat("MM/dd/yyyy", Locale.US);

    private TrueScaleDatabaseHelper databaseHelper;

    private long userId;
    private long entryId = NO_ENTRY;

    /** The date currently chosen in the picker. */
    private final Calendar selectedDate = Calendar.getInstance();

    private EditText editDate;
    private EditText editWeight;
    private TextView textAddStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        databaseHelper = new TrueScaleDatabaseHelper(this);

        userId = getIntent().getLongExtra(EXTRA_USER_ID, NO_ENTRY);
        entryId = getIntent().getLongExtra(EXTRA_ENTRY_ID, NO_ENTRY);

        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        textAddStatus = findViewById(R.id.textAddStatus);

        Button buttonSaveEntry = findViewById(R.id.buttonSaveEntry);
        Button buttonCancelEntry = findViewById(R.id.buttonCancelEntry);

        // The date field opens a calendar instead of the keyboard, so the
        // user cannot type a date the database would have to reject.
        editDate.setFocusable(false);
        editDate.setClickable(true);
        editDate.setOnClickListener(v -> showDatePicker());

        buttonSaveEntry.setOnClickListener(v -> attemptSave());
        buttonCancelEntry.setOnClickListener(v -> finish());

        if (isEditing()) {
            setTitle(R.string.title_edit_weight);
            loadExistingEntry();
        } else {
            // A new entry defaults to today, which is the common case.
            showSelectedDate();
        }
    }

    /** True when this screen was opened to change an entry that already exists. */
    private boolean isEditing() {
        return entryId != NO_ENTRY;
    }

    /** Fills the fields with the values of the entry being edited. */
    private void loadExistingEntry() {
        WeightEntry entry = databaseHelper.getWeightEntry(entryId);

        if (entry == null) {
            // The row was deleted while this screen was opening. Nothing to
            // edit, so close rather than saving against a missing id.
            finish();
            return;
        }

        try {
            java.util.Date parsed = isoFormat.parse(entry.getIsoDate());
            if (parsed != null) {
                selectedDate.setTime(parsed);
            }
        } catch (java.text.ParseException e) {
            // Leave the picker on today's date if the stored value is bad.
        }

        showSelectedDate();
        editWeight.setText(String.format(Locale.US, "%.1f", entry.getWeight()));
    }

    /** Opens the calendar dialog, starting on the currently chosen date. */
    private void showDatePicker() {
        DatePickerDialog dialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    selectedDate.set(year, month, dayOfMonth);
                    showSelectedDate();
                },
                selectedDate.get(Calendar.YEAR),
                selectedDate.get(Calendar.MONTH),
                selectedDate.get(Calendar.DAY_OF_MONTH));

        // A weigh-in cannot happen in the future, so later dates are blocked.
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        dialog.show();
    }

    /** Writes the chosen date into the field in the format the user expects. */
    private void showSelectedDate() {
        editDate.setText(displayFormat.format(selectedDate.getTime()));
    }

    /**
     * Validates both fields and then either inserts a new row or updates the
     * existing one. Invalid input leaves the user on this screen with a
     * message rather than discarding what they typed.
     */
    private void attemptSave() {
        String dateText = editDate.getText().toString().trim();
        String weightText = editWeight.getText().toString().trim();

        if (TextUtils.isEmpty(dateText)) {
            showError(R.string.error_no_date);
            return;
        }

        if (TextUtils.isEmpty(weightText)) {
            showError(R.string.error_missing_entry);
            return;
        }

        double weight;
        try {
            weight = Double.parseDouble(weightText);
        } catch (NumberFormatException e) {
            showError(R.string.error_invalid_weight);
            return;
        }

        if (weight < MIN_WEIGHT || weight > MAX_WEIGHT) {
            showError(R.string.error_invalid_weight);
            return;
        }

        String isoDate = isoFormat.format(selectedDate.getTime());

        if (isEditing()) {
            databaseHelper.updateWeightEntry(entryId, isoDate, weight);
        } else {
            databaseHelper.addWeightEntry(userId, isoDate, weight);
        }

        textAddStatus.setVisibility(View.GONE);
        finish();
    }

    private void showError(int messageResourceId) {
        textAddStatus.setText(messageResourceId);
        textAddStatus.setVisibility(View.VISIBLE);
    }
}