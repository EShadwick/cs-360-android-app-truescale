package com.example.truescale_shadwick;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Base64;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/**
 * Single point of access to the TrueScale SQLite database.
 *
 * Two tables are defined. The users table holds account credentials, the
 * user's goal weight, and their alert settings. The daily_weights table
 * holds the weigh-in history, with every row tied to the user who created it.
 *
 * Passwords are never stored in readable form. Each account gets its own
 * random salt, and only the SHA-256 hash of salt plus password is written to
 * the database, so the stored value cannot be read back as the password.
 */
public class TrueScaleDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "truescale.db";
    private static final int DATABASE_VERSION = 2;

    /** Returned by account methods when no user matches. */
    public static final long NO_USER = -1L;

    /** Stored when no weigh-in has triggered a goal alert yet. */
    public static final long NO_ENTRY = -1L;

    // users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD_HASH = "password_hash";
    private static final String COL_SALT = "salt";
    private static final String COL_GOAL_WEIGHT = "goal_weight";
    private static final String COL_PHONE_NUMBER = "phone_number";
    private static final String COL_ALERTS_ENABLED = "alerts_enabled";
    private static final String COL_LAST_ALERT_ENTRY_ID = "last_alert_entry_id";

    // daily_weights table
    private static final String TABLE_WEIGHTS = "daily_weights";
    private static final String COL_WEIGHT_ID = "_id";
    private static final String COL_WEIGHT_USER_ID = "user_id";
    private static final String COL_ENTRY_DATE = "entry_date";
    private static final String COL_WEIGHT_VALUE = "weight";

    /** Goal applied to a new account until the user sets their own. */
    private static final double DEFAULT_GOAL_WEIGHT = 185.0;

    public TrueScaleDatabaseHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(@NonNull SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT NOT NULL UNIQUE, "
                + COL_PASSWORD_HASH + " TEXT NOT NULL, "
                + COL_SALT + " TEXT NOT NULL, "
                + COL_GOAL_WEIGHT + " REAL NOT NULL DEFAULT " + DEFAULT_GOAL_WEIGHT + ", "
                + COL_PHONE_NUMBER + " TEXT NOT NULL DEFAULT '', "
                + COL_ALERTS_ENABLED + " INTEGER NOT NULL DEFAULT 0, "
                + COL_LAST_ALERT_ENTRY_ID + " INTEGER NOT NULL DEFAULT " + NO_ENTRY + ")");

        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " ("
                + COL_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_WEIGHT_USER_ID + " INTEGER NOT NULL, "
                + COL_ENTRY_DATE + " TEXT NOT NULL, "
                + COL_WEIGHT_VALUE + " REAL NOT NULL, "
                + "FOREIGN KEY (" + COL_WEIGHT_USER_ID + ") REFERENCES "
                + TABLE_USERS + "(" + COL_USER_ID + ") ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(@NonNull SQLiteDatabase db, int oldVersion, int newVersion) {
        // TrueScale is still in development and has no released data worth
        // preserving, so the schema is rebuilt rather than migrated.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    @Override
    public void onConfigure(@NonNull SQLiteDatabase db) {
        super.onConfigure(db);
        // Required for the ON DELETE CASCADE clause above to take effect.
        db.setForeignKeyConstraintsEnabled(true);
    }

    // ---------------------------------------------------------------
    // Account management
    // ---------------------------------------------------------------

    /**
     * Returns true when the username is already taken. Checked before an
     * insert so the user gets a clear message instead of a constraint error.
     */
    public boolean usernameExists(@NonNull String username) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null)) {
            return cursor.moveToFirst();
        }
    }

    /**
     * Creates a new account and returns its row id, or NO_USER if the
     * username is taken or the insert fails.
     */
    public long createUser(@NonNull String username, @NonNull String password) {
        if (usernameExists(username)) {
            return NO_USER;
        }

        String salt = generateSalt();

        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_SALT, salt);
        values.put(COL_PASSWORD_HASH, hashPassword(password, salt));
        values.put(COL_GOAL_WEIGHT, DEFAULT_GOAL_WEIGHT);

        long newId = getWritableDatabase().insert(TABLE_USERS, null, values);
        return newId == -1 ? NO_USER : newId;
    }

    /**
     * Checks a username and password against the database. Returns the user's
     * row id on success, or NO_USER when the account does not exist or the
     * password does not match.
     */
    public long validateUser(@NonNull String username, @NonNull String password) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_USERS,
                new String[]{COL_USER_ID, COL_PASSWORD_HASH, COL_SALT},
                COL_USERNAME + " = ?",
                new String[]{username},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                return NO_USER;
            }

            long userId = cursor.getLong(cursor.getColumnIndexOrThrow(COL_USER_ID));
            String storedHash = cursor.getString(cursor.getColumnIndexOrThrow(COL_PASSWORD_HASH));
            String salt = cursor.getString(cursor.getColumnIndexOrThrow(COL_SALT));

            // The supplied password is hashed with the stored salt and the
            // results compared. The original password is never recovered.
            return storedHash.equals(hashPassword(password, salt)) ? userId : NO_USER;
        }
    }

    // ---------------------------------------------------------------
    // Goal and alert settings
    // ---------------------------------------------------------------

    public double getGoalWeight(long userId) {
        return readDouble(userId, COL_GOAL_WEIGHT, DEFAULT_GOAL_WEIGHT);
    }

    /** The number goal alerts are sent to. Empty when the user has not set one. */
    @NonNull
    public String getPhoneNumber(long userId) {
        try (Cursor cursor = queryUserColumn(userId, COL_PHONE_NUMBER)) {
            if (cursor.moveToFirst()) {
                return cursor.getString(0);
            }
            return "";
        }
    }

    /** Whether the user has switched goal alerts on. */
    public boolean areAlertsEnabled(long userId) {
        try (Cursor cursor = queryUserColumn(userId, COL_ALERTS_ENABLED)) {
            return cursor.moveToFirst() && cursor.getInt(0) == 1;
        }
    }

    /**
     * The weigh-in that most recently triggered a goal alert. Recording this
     * stops the app from re-sending the same alert every time the weight log
     * is reopened.
     */
    public long getLastAlertEntryId(long userId) {
        try (Cursor cursor = queryUserColumn(userId, COL_LAST_ALERT_ENTRY_ID)) {
            if (cursor.moveToFirst()) {
                return cursor.getLong(0);
            }
            return NO_ENTRY;
        }
    }

    public boolean setLastAlertEntryId(long userId, long entryId) {
        ContentValues values = new ContentValues();
        values.put(COL_LAST_ALERT_ENTRY_ID, entryId);
        return updateUser(userId, values);
    }

    /**
     * Saves the goal weight, alert phone number, and alert switch together,
     * because the settings screen presents them as one set of choices.
     */
    public boolean saveAlertSettings(long userId,
                                     double goalWeight,
                                     @NonNull String phoneNumber,
                                     boolean alertsEnabled) {
        ContentValues values = new ContentValues();
        values.put(COL_GOAL_WEIGHT, goalWeight);
        values.put(COL_PHONE_NUMBER, phoneNumber);
        values.put(COL_ALERTS_ENABLED, alertsEnabled ? 1 : 0);
        return updateUser(userId, values);
    }

    /** Used when the switch is toggled on its own, without saving the goal. */
    public boolean setAlertsEnabled(long userId, boolean alertsEnabled) {
        ContentValues values = new ContentValues();
        values.put(COL_ALERTS_ENABLED, alertsEnabled ? 1 : 0);
        return updateUser(userId, values);
    }

    // ---------------------------------------------------------------
    // Weight entries: create, read, update, delete
    // ---------------------------------------------------------------

    /**
     * Inserts a weigh-in. The date must already be in yyyy-MM-dd form.
     * Returns the new row id, or -1 on failure.
     */
    public long addWeightEntry(long userId, @NonNull String isoDate, double weight) {
        ContentValues values = new ContentValues();
        values.put(COL_WEIGHT_USER_ID, userId);
        values.put(COL_ENTRY_DATE, isoDate);
        values.put(COL_WEIGHT_VALUE, weight);

        return getWritableDatabase().insert(TABLE_WEIGHTS, null, values);
    }

    /** Changes the date and weight of an existing entry. */
    public boolean updateWeightEntry(long entryId, @NonNull String isoDate, double weight) {
        ContentValues values = new ContentValues();
        values.put(COL_ENTRY_DATE, isoDate);
        values.put(COL_WEIGHT_VALUE, weight);

        int rowsChanged = getWritableDatabase().update(
                TABLE_WEIGHTS,
                values,
                COL_WEIGHT_ID + " = ?",
                new String[]{String.valueOf(entryId)});

        return rowsChanged > 0;
    }

    /** Removes a single entry, targeted by row id rather than screen position. */
    public boolean deleteWeightEntry(long entryId) {
        int rowsDeleted = getWritableDatabase().delete(
                TABLE_WEIGHTS,
                COL_WEIGHT_ID + " = ?",
                new String[]{String.valueOf(entryId)});

        return rowsDeleted > 0;
    }

    /** Loads one entry for editing, or null if the id is not found. */
    @Nullable
    public WeightEntry getWeightEntry(long entryId) {
        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHTS,
                new String[]{COL_WEIGHT_ID, COL_ENTRY_DATE, COL_WEIGHT_VALUE},
                COL_WEIGHT_ID + " = ?",
                new String[]{String.valueOf(entryId)},
                null, null, null)) {

            if (!cursor.moveToFirst()) {
                return null;
            }

            return new WeightEntry(
                    cursor.getLong(cursor.getColumnIndexOrThrow(COL_WEIGHT_ID)),
                    cursor.getString(cursor.getColumnIndexOrThrow(COL_ENTRY_DATE)),
                    cursor.getDouble(cursor.getColumnIndexOrThrow(COL_WEIGHT_VALUE)),
                    0.0);
        }
    }

    /**
     * Returns every entry for a user, newest first, with the change since the
     * previous weigh-in calculated for each row. The oldest entry has no
     * earlier reading to compare against, so its change is zero.
     */
    @NonNull
    public List<WeightEntry> getWeightEntries(long userId) {
        List<WeightEntry> entries = new ArrayList<>();

        try (Cursor cursor = getReadableDatabase().query(
                TABLE_WEIGHTS,
                new String[]{COL_WEIGHT_ID, COL_ENTRY_DATE, COL_WEIGHT_VALUE},
                COL_WEIGHT_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null, null,
                COL_ENTRY_DATE + " DESC, " + COL_WEIGHT_ID + " DESC")) {

            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_WEIGHT_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(COL_ENTRY_DATE));
                double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(COL_WEIGHT_VALUE));

                entries.add(new WeightEntry(id, date, weight, 0.0));
            }
        }

        return withCalculatedChanges(entries);
    }

    /**
     * Rebuilds the list with each entry's change set to the difference
     * between it and the older entry that follows it.
     */
    @NonNull
    private List<WeightEntry> withCalculatedChanges(@NonNull List<WeightEntry> newestFirst) {
        List<WeightEntry> result = new ArrayList<>(newestFirst.size());

        for (int i = 0; i < newestFirst.size(); i++) {
            WeightEntry current = newestFirst.get(i);
            double change = 0.0;

            if (i + 1 < newestFirst.size()) {
                change = current.getWeight() - newestFirst.get(i + 1).getWeight();
            }

            result.add(new WeightEntry(
                    current.getId(),
                    current.getIsoDate(),
                    current.getWeight(),
                    change));
        }

        return result;
    }

    // ---------------------------------------------------------------
    // Shared helpers
    // ---------------------------------------------------------------

    /** Runs a single column lookup against one user row. */
    @NonNull
    private Cursor queryUserColumn(long userId, @NonNull String columnName) {
        return getReadableDatabase().query(
                TABLE_USERS,
                new String[]{columnName},
                COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)},
                null, null, null);
    }

    private double readDouble(long userId, @NonNull String columnName, double fallback) {
        try (Cursor cursor = queryUserColumn(userId, columnName)) {
            return cursor.moveToFirst() ? cursor.getDouble(0) : fallback;
        }
    }

    private boolean updateUser(long userId, @NonNull ContentValues values) {
        int rowsChanged = getWritableDatabase().update(
                TABLE_USERS,
                values,
                COL_USER_ID + " = ?",
                new String[]{String.valueOf(userId)});

        return rowsChanged > 0;
    }

    // ---------------------------------------------------------------
    // Password hashing
    // ---------------------------------------------------------------

    /** Produces a random 16 byte salt, encoded as text for storage. */
    @NonNull
    private String generateSalt() {
        byte[] saltBytes = new byte[16];
        new SecureRandom().nextBytes(saltBytes);
        return Base64.encodeToString(saltBytes, Base64.NO_WRAP);
    }

    /**
     * Hashes the salt and password together with SHA-256. The same input
     * always produces the same output, which is what makes login checks
     * possible without ever storing the password itself.
     */
    @NonNull
    private String hashPassword(@NonNull String password, @NonNull String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            digest.update(salt.getBytes());
            byte[] hashed = digest.digest(password.getBytes());
            return Base64.encodeToString(hashed, Base64.NO_WRAP);
        } catch (NoSuchAlgorithmException e) {
            // SHA-256 is part of every Android platform release, so this
            // branch is unreachable in practice.
            throw new IllegalStateException("SHA-256 is not available", e);
        }
    }
}