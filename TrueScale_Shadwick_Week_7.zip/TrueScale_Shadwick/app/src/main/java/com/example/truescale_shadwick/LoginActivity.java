package com.example.truescale_shadwick;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Launcher screen. Checks credentials against the users table and creates
 * new accounts for first time users. On success the signed in user's row id
 * is handed to MainActivity so every screen knows whose data to load.
 */
public class LoginActivity extends AppCompatActivity {

    /** Intent extra key carrying the signed in user's row id. */
    public static final String EXTRA_USER_ID = "com.example.truescale_shadwick.USER_ID";

    private TrueScaleDatabaseHelper databaseHelper;

    private EditText editUsername;
    private EditText editPassword;
    private TextView textLoginStatus;
    private Button buttonSignIn;
    private Button buttonCreateAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        databaseHelper = new TrueScaleDatabaseHelper(this);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        textLoginStatus = findViewById(R.id.textLoginStatus);
        buttonSignIn = findViewById(R.id.buttonSignIn);
        buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Both buttons stay disabled until there is something in both fields.
        TextWatcher fieldWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // no-op
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                updateButtonState();
            }

            @Override
            public void afterTextChanged(Editable s) {
                // no-op
            }
        };

        editUsername.addTextChangedListener(fieldWatcher);
        editPassword.addTextChangedListener(fieldWatcher);
        updateButtonState();

        buttonSignIn.setOnClickListener(v -> attemptSignIn());
        buttonCreateAccount.setOnClickListener(v -> attemptCreateAccount());
    }

    /**
     * Note the deliberate use of TextUtils.isEmpty here. Writing this as
     * length() > 0 invites an IDE quick-fix that can silently invert the
     * condition and enable the buttons on empty fields.
     */
    private void updateButtonState() {
        boolean hasUsername = !TextUtils.isEmpty(editUsername.getText().toString().trim());
        boolean hasPassword = !TextUtils.isEmpty(editPassword.getText().toString().trim());
        boolean bothFilled = hasUsername && hasPassword;

        buttonSignIn.setEnabled(bothFilled);
        buttonCreateAccount.setEnabled(bothFilled);
    }

    /**
     * Checks the typed credentials against the database. A failed check shows
     * a message and leaves the user on this screen.
     */
    private void attemptSignIn() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        long userId = databaseHelper.validateUser(username, password);

        if (userId == TrueScaleDatabaseHelper.NO_USER) {
            textLoginStatus.setText(R.string.login_invalid);
            return;
        }

        openWeightLog(userId);
    }

    /**
     * Creates an account for a first time user and signs them straight in.
     * Usernames must be unique, so an existing name is reported rather than
     * silently overwriting the account that already holds it.
     */
    private void attemptCreateAccount() {
        String username = editUsername.getText().toString().trim();
        String password = editPassword.getText().toString();

        if (databaseHelper.usernameExists(username)) {
            textLoginStatus.setText(R.string.login_username_taken);
            return;
        }

        long userId = databaseHelper.createUser(username, password);

        if (userId == TrueScaleDatabaseHelper.NO_USER) {
            textLoginStatus.setText(R.string.login_create_failed);
            return;
        }

        textLoginStatus.setText(R.string.login_account_created);
        openWeightLog(userId);
    }

    /**
     * Opens the weight log for the given user and closes this screen, so the
     * back button from the log exits the app rather than returning to a
     * login form the user has already passed.
     */
    private void openWeightLog(long userId) {
        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
        intent.putExtra(EXTRA_USER_ID, userId);
        startActivity(intent);
        finish();
    }
}