package com.example.truescale_shadwick;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;
import java.util.Locale;

/**
 * Binds WeightEntry objects to item_weight_row.xml. Row actions are reported
 * by database row id rather than screen position, so deleting or editing
 * always targets the intended record even as the list changes.
 */
public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightViewHolder> {

    /** Receives taps on a row and on a row's delete button. */
    public interface OnEntryActionListener {
        void onDeleteClick(long entryId);

        void onEditClick(long entryId);
    }

    private final List<WeightEntry> entries;
    private final OnEntryActionListener actionListener;

    public WeightAdapter(List<WeightEntry> entries, OnEntryActionListener actionListener) {
        this.entries = entries;
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public WeightViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_row, parent, false);
        return new WeightViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WeightViewHolder holder, int position) {
        WeightEntry entry = entries.get(position);

        holder.textRowDate.setText(entry.getDisplayDate());
        holder.textRowWeight.setText(String.format(Locale.US, "%.1f", entry.getWeight()));

        double change = entry.getChange();
        holder.textRowChange.setText(String.format(Locale.US, "%+.1f", change));

        // A day with no change is neither a gain nor a loss, so it is shown
        // in a neutral color rather than being grouped with one of them.
        int changeColor;
        if (change > 0) {
            changeColor = R.color.ts_up;
        } else if (change < 0) {
            changeColor = R.color.ts_down;
        } else {
            changeColor = R.color.ts_neutral;
        }

        holder.textRowChange.setTextColor(
                ContextCompat.getColor(holder.itemView.getContext(), changeColor));

        holder.buttonDeleteRow.setOnClickListener(v -> {
            int adapterPosition = holder.getBindingAdapterPosition();
            if (actionListener != null && adapterPosition != RecyclerView.NO_POSITION) {
                actionListener.onDeleteClick(entries.get(adapterPosition).getId());
            }
        });

        // Tapping anywhere else on the row opens it for editing.
        holder.itemView.setOnClickListener(v -> {
            int adapterPosition = holder.getBindingAdapterPosition();
            if (actionListener != null && adapterPosition != RecyclerView.NO_POSITION) {
                actionListener.onEditClick(entries.get(adapterPosition).getId());
            }
        });
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    static class WeightViewHolder extends RecyclerView.ViewHolder {

        final TextView textRowDate;
        final TextView textRowWeight;
        final TextView textRowChange;
        final ImageButton buttonDeleteRow;

        WeightViewHolder(@NonNull View itemView) {
            super(itemView);
            textRowDate = itemView.findViewById(R.id.textRowDate);
            textRowWeight = itemView.findViewById(R.id.textRowWeight);
            textRowChange = itemView.findViewById(R.id.textRowChange);
            buttonDeleteRow = itemView.findViewById(R.id.buttonDeleteRow);
        }
    }
}