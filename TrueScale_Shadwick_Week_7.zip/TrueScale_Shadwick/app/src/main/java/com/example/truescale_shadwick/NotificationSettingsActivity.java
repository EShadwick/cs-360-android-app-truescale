package com.example.truescale_shadwick;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;

import java.util.Locale;

/**
 * Goal weight, alert phone number, and the SMS alert setting, all stored
 * against the signed in user's account.
 *
 * SMS Notifications criterion: the app checks for SEND_SMS before it would
 * ever send, requests it from the user when it is missing, and degrades
 * gracefully if the user declines. Declining disables alerts only; every
 * other part of TrueScale continues to work.
 */
public class NotificationSettingsActivity extends AppCompatActivity {

    private static final double MIN_GOAL_WEIGHT = 50.0;
    private static final double MAX_GOAL_WEIGHT = 1000.0;

    private TrueScaleDatabaseHelper databaseHelper;
    private long userId = TrueScaleDatabaseHelper.NO_USER;

    private SwitchCompat switchSmsAlerts;
    private TextView textPermissionStatus;
    private TextView textDeniedNotice;
    private Button buttonRequestPermission;
    private Button buttonSendTest;
    private EditText editGoalWeight;
    private EditText editPhoneNumber;

    /**
     * Registered up front, per the AndroidX contract. The callback fires with
     * the user's answer to the system permission dialog.
     */
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (!isGranted) {
                            // Declining turns the alert off but leaves the
                            // rest of TrueScale fully usable.
                            switchSmsAlerts.setChecked(false);
                            databaseHelper.setAlertsEnabled(userId, false);
                        }
                        refreshPermissionUi();
                    });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);

        databaseHelper = new TrueScaleDatabaseHelper(this);
        userId = getIntent().getLongExtra(
                LoginActivity.EXTRA_USER_ID, TrueScaleDatabaseHelper.NO_USER);

        if (userId == TrueScaleDatabaseHelper.NO_USER) {
            // No account means nothing to save against, so close instead of
            // letting the user edit settings that would be discarded.
            finish();
            return;
        }

        switchSmsAlerts = findViewById(R.id.switchSmsAlerts);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        textDeniedNotice = findViewById(R.id.textDeniedNotice);
        buttonRequestPermission = findViewById(R.id.buttonRequestPermission);
        buttonSendTest = findViewById(R.id.buttonSendTest);
        editGoalWeight = findViewById(R.id.editGoalWeight);
        editPhoneNumber = findViewById(R.id.editPhoneNumber);

        Button buttonSaveGoal = findViewById(R.id.buttonSaveGoal);
        Button buttonBackToLog = findViewById(R.id.buttonBackToLog);

        loadSavedSettings();

        // Turning the switch on is what triggers the permission request,
        // so the ask always has visible context behind it.
        switchSmsAlerts.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !hasSmsPermission()) {
                requestSmsPermission();
            } else {
                databaseHelper.setAlertsEnabled(userId, isChecked);
                refreshPermissionUi();
            }
        });

        buttonRequestPermission.setOnClickListener(v -> requestSmsPermission());

        buttonSendTest.setOnClickListener(v -> sendTestMessage());

        buttonSaveGoal.setOnClickListener(v -> saveSettings());

        buttonBackToLog.setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // The user may have changed the permission in system Settings.
        refreshPermissionUi();
    }

    /** Fills the fields with what this account already has stored. */
    private void loadSavedSettings() {
        editGoalWeight.setText(String.format(
                Locale.US, "%.1f", databaseHelper.getGoalWeight(userId)));
        editPhoneNumber.setText(databaseHelper.getPhoneNumber(userId));

        // Alerts can only be on if the permission is still granted, since the
        // user may have revoked it in system Settings since the last visit.
        boolean alertsOn = databaseHelper.areAlertsEnabled(userId) && hasSmsPermission();
        switchSmsAlerts.setChecked(alertsOn);
    }

    /**
     * Validates and stores the goal, phone number, and switch position
     * together. A bad value leaves the screen open with a message so the
     * user can correct it.
     */
    private void saveSettings() {
        String goalText = editGoalWeight.getText().toString().trim();
        String phoneNumber = editPhoneNumber.getText().toString().trim();
        boolean alertsOn = switchSmsAlerts.isChecked();

        double goalWeight;
        try {
            goalWeight = Double.parseDouble(goalText);
        } catch (NumberFormatException e) {
            Toast.makeText(this, R.string.msg_invalid_goal, Toast.LENGTH_LONG).show();
            return;
        }

        if (goalWeight < MIN_GOAL_WEIGHT || goalWeight > MAX_GOAL_WEIGHT) {
            Toast.makeText(this, R.string.msg_invalid_goal, Toast.LENGTH_LONG).show();
            return;
        }

        // Alerts have nowhere to go without a number, so the switch cannot
        // be saved as on until one is entered.
        if (alertsOn && TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this, R.string.msg_phone_required, Toast.LENGTH_LONG).show();
            return;
        }

        databaseHelper.saveAlertSettings(userId, goalWeight, phoneNumber, alertsOn);
        Toast.makeText(this, R.string.msg_settings_saved, Toast.LENGTH_SHORT).show();
    }

    /** Sends a fixed message so the user can confirm alerts reach their phone. */
    private void sendTestMessage() {
        if (!hasSmsPermission()) {
            requestSmsPermission();
            return;
        }

        String phoneNumber = editPhoneNumber.getText().toString().trim();

        if (TextUtils.isEmpty(phoneNumber)) {
            Toast.makeText(this, R.string.msg_phone_required, Toast.LENGTH_LONG).show();
            return;
        }

        if (sendSms(this, phoneNumber, getString(R.string.sms_test_body))) {
            Toast.makeText(this, R.string.msg_test_sent, Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, R.string.msg_sms_failed, Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Sends one text message and reports whether it went out. Shared with
     * MainActivity so the goal alert and the test message follow exactly the
     * same path, including the permission check.
     *
     * Returns false rather than throwing, so a failure to send can never
     * bring down the screen that asked for it.
     */
    static boolean sendSms(@androidx.annotation.NonNull android.content.Context context,
                           @androidx.annotation.NonNull String phoneNumber,
                           @androidx.annotation.NonNull String message) {

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return false;
        }

        SmsManager smsManager = getSmsManager(context);

        if (smsManager == null) {
            return false;
        }

        try {
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            return true;
        } catch (IllegalArgumentException | SecurityException e) {
            // An invalid number or a permission revoked between the check and
            // the send both land here.
            return false;
        }
    }

    /**
     * Obtains the SmsManager in the way the running platform version
     * supports. TrueScale targets devices back to Android 7.0, and the
     * system service lookup was only added in Android 12, so older releases
     * fall back to the older static accessor.
     */
    @SuppressWarnings("deprecation")
    @androidx.annotation.Nullable
    private static SmsManager getSmsManager(@androidx.annotation.NonNull android.content.Context context) {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            return context.getSystemService(SmsManager.class);
        }
        return SmsManager.getDefault();
    }

    private boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;
    }

    private boolean deviceCanSendSms() {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_TELEPHONY);
    }

    private void requestSmsPermission() {
        if (!deviceCanSendSms()) {
            Toast.makeText(this, R.string.msg_no_telephony, Toast.LENGTH_LONG).show();
            switchSmsAlerts.setChecked(false);
            return;
        }
        smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    /** Single place that decides what the permission group looks like. */
    private void refreshPermissionUi() {
        boolean granted = hasSmsPermission();

        textPermissionStatus.setText(granted
                ? R.string.status_permission_granted
                : R.string.status_permission_needed);
        textPermissionStatus.setTextColor(ContextCompat.getColor(this,
                granted ? R.color.ts_down : R.color.ts_text_secondary));

        buttonRequestPermission.setVisibility(granted ? View.GONE : View.VISIBLE);
        buttonSendTest.setEnabled(granted && switchSmsAlerts.isChecked());
        textDeniedNotice.setVisibility(granted ? View.GONE : View.VISIBLE);

        if (granted) {
            switchSmsAlerts.setEnabled(true);
        }
    }
}