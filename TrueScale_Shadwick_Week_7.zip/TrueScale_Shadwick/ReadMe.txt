TrueScale - Weight Tracking App
CS 360: Mobile Architecture and Programming
Project Two: App UI Design (Option 3)
Eric Shadwick


PROJECT CONTENTS

This submission contains the complete Android Studio project for the TrueScale
user interface. The following screens are implemented:

  Login / Create Account        activity_login.xml
  Weight Log (database grid)    activity_main.xml, item_weight_row.xml
  Add Weight Entry              activity_add_weight.xml
  Goal and Alerts (SMS)         activity_notification_settings.xml

The SEND_SMS permission and the telephony feature are declared in
AndroidManifest.xml. The application checks for SMS permission before it would
send a message, requests the permission from the user when it is missing, and
continues to function normally if the user declines.


AI ACKNOWLEDGMENT

The TrueScale app concept, screen structure, and database design are my own,
carried forward from my Project One proposal. For this project I determined how
the required screens should be organized, chose to place the SMS permission
request on a dedicated settings screen rather than burying it in a dialog, and
installed, configured, built, and tested the application in Android Studio,
including verifying both the grant and deny paths for the SEND_SMS permission on
an emulator. I used Claude, an AI assistant developed by Anthropic, to generate
the layout XML, style and theme resources, manifest declarations, and supporting
Java classes that implement those decisions, and to help troubleshoot build
errors.


REFERENCE

Anthropic. (2026). Claude (Opus 5) [Large language model]. https://claude.ai
